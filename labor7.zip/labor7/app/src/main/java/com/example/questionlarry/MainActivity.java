package com.example.questionlarry;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //load the initial formFragment
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        FormFragment formFragment=new FormFragment();
        fragmentTransaction.add(R.id.fg_placeholder,formFragment);
        fragmentTransaction.commit();
    }
}
